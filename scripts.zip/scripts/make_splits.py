# scripts/make_splits.py
import os, glob, pandas as pd, random
random.seed(42)

# adjust paths if needed
real_dir = "data/raw/real"
fake_dir = "data/raw/fake"

# If you have a mapping file fake_to_orig.csv with columns: fake_filename, orig_filename
map_path = "data/raw/fake_to_orig.csv"  # optional

rows = []
# real videos
for p in glob.glob(os.path.join(real_dir, "*.mp4")):
    vid = os.path.basename(p)
    orig_id = vid  # original itself
    rows.append({"path": p, "video_id": vid, "orig_id": orig_id, "label": 0})

# fake videos - attempt to infer orig_id or use map
if os.path.exists(map_path):
    mdf = pd.read_csv(map_path)
    for _,r in mdf.iterrows():
        fake_name = r['fake_filename']
        orig_name = r['orig_filename']
        p = os.path.join(fake_dir, fake_name)
        if os.path.exists(p):
            rows.append({"path": p, "video_id": fake_name, "orig_id": orig_name, "label": 1})
else:
    # try to infer: assume fake filename contains original filename prefix like orig123_fake1.mp4
    for p in glob.glob(os.path.join(fake_dir, "*.mp4")):
        fn = os.path.basename(p)
        # naive heuristic: orig id is first token before '_' or '-'
        orig_guess = fn.split('_')[0]
        rows.append({"path": p, "video_id": fn, "orig_id": orig_guess, "label": 1})

df = pd.DataFrame(rows)
# Deduplicate and sanity-check
print("Total videos:", len(df))
print("Unique originals (orig_id):", df.orig_id.nunique())

# create splits by orig_id
orig_ids = sorted(df.orig_id.unique())
random.shuffle(orig_ids)
n = len(orig_ids)
train_cut = int(0.8 * n)
val_cut = int(0.9 * n)
train_ids = set(orig_ids[:train_cut])
val_ids = set(orig_ids[train_cut:val_cut])
test_ids = set(orig_ids[val_cut:])

def assign_split(r):
    if r.orig_id in train_ids: return "train"
    if r.orig_id in val_ids: return "val"
    return "test"

df['split'] = df.apply(assign_split, axis=1)

os.makedirs("data/splits", exist_ok=True)
df.to_csv("data/splits/videos_with_orig.csv", index=False)
df[df.split=="train"].to_csv("data/splits/train_videos.txt", index=False, columns=["path"])
df[df.split=="val"].to_csv("data/splits/val_videos.txt", index=False, columns=["path"])
df[df.split=="test"].to_csv("data/splits/test_videos.txt", index=False, columns=["path"])
print("Wrote data/splits/videos_with_orig.csv and split lists")
