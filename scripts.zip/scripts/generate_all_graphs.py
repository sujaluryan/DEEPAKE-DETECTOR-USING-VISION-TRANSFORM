import torch
import torch.nn as nn
import timm
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from torchvision import datasets, transforms
from torch.utils.data import DataLoader

from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
    roc_curve,
    auc,
    precision_recall_curve
)

from sklearn.calibration import calibration_curve


device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# =============================
# Load Model
# =============================

model = timm.create_model("vit_base_patch16_224", pretrained=False)
model.head = nn.Linear(model.head.in_features, 2)

model.load_state_dict(
    torch.load("checkpoints/vit_deepfake_model.pth", map_location=device)
)

model = model.to(device)
model.eval()

# =============================
# Dataset
# =============================

transform = transforms.Compose([
    transforms.Resize((224,224)),
    transforms.ToTensor()
])

dataset = datasets.ImageFolder("data/faces", transform=transform)

loader = DataLoader(dataset, batch_size=32)


# =============================
# Inference
# =============================

all_preds = []
all_labels = []
all_probs = []

with torch.no_grad():

    for images, labels in loader:

        images = images.to(device)

        outputs = model(images)

        probs = torch.softmax(outputs, dim=1)

        preds = torch.argmax(probs, dim=1)

        all_preds.extend(preds.cpu().numpy())
        all_labels.extend(labels.numpy())
        all_probs.extend(probs[:,1].cpu().numpy())


all_preds = np.array(all_preds)
all_labels = np.array(all_labels)
all_probs = np.array(all_probs)


# =============================
# Metrics
# =============================

accuracy = accuracy_score(all_labels, all_preds)
precision = precision_score(all_labels, all_preds)
recall = recall_score(all_labels, all_preds)
f1 = f1_score(all_labels, all_preds)


# =============================
# Performance Metrics Graph
# =============================

metrics = [accuracy, precision, recall, f1]
names = ["Accuracy", "Precision", "Recall", "F1"]

plt.figure(figsize=(6,4))
plt.bar(names, metrics)
plt.title("Performance Metrics")
plt.savefig("performance_metrics.png")
plt.close()


# =============================
# Confusion Matrix
# =============================

cm = confusion_matrix(all_labels, all_preds)

plt.figure(figsize=(6,6))
sns.heatmap(cm, annot=True, fmt="d", cmap="Blues")

plt.title("Confusion Matrix")
plt.xlabel("Predicted")
plt.ylabel("Actual")

plt.savefig("confusion_matrix.png")
plt.close()


# =============================
# Real vs Fake Comparison
# =============================

real_correct = cm[0,0]
fake_correct = cm[1,1]

plt.figure(figsize=(6,4))

plt.bar(["Real", "Fake"], [real_correct, fake_correct])

plt.title("Real vs Fake Correct Predictions")

plt.savefig("real_vs_fake_comparison.png")
plt.close()


# =============================
# Class-wise Accuracy
# =============================

real_acc = cm[0,0] / (cm[0,0] + cm[0,1])
fake_acc = cm[1,1] / (cm[1,0] + cm[1,1])

plt.figure(figsize=(6,4))

plt.bar(["Real", "Fake"], [real_acc, fake_acc])

plt.title("Class-wise Accuracy")

plt.savefig("classwise_accuracy.png")
plt.close()


# =============================
# ROC Curve
# =============================

fpr, tpr, _ = roc_curve(all_labels, all_probs)

roc_auc = auc(fpr, tpr)

plt.figure()

plt.plot(fpr, tpr, label=f"AUC = {roc_auc:.2f}")
plt.plot([0,1], [0,1], "--")

plt.xlabel("False Positive Rate")
plt.ylabel("True Positive Rate")

plt.title("ROC Curve")
plt.legend()

plt.savefig("roc_curve.png")
plt.close()


# =============================
# Precision Recall Curve
# =============================

precision_vals, recall_vals, _ = precision_recall_curve(all_labels, all_probs)

plt.figure()

plt.plot(recall_vals, precision_vals)

plt.xlabel("Recall")
plt.ylabel("Precision")

plt.title("Precision Recall Curve")

plt.savefig("precision_recall_curve.png")
plt.close()


# =============================
# Threshold Sensitivity
# =============================

thresholds = np.linspace(0,1,50)

acc_scores = []

for t in thresholds:

    preds = (all_probs > t).astype(int)

    acc_scores.append(
        accuracy_score(all_labels, preds)
    )

plt.figure()

plt.plot(thresholds, acc_scores)

plt.xlabel("Threshold")
plt.ylabel("Accuracy")

plt.title("Threshold Sensitivity")

plt.savefig("threshold_sensitivity.png")
plt.close()


# =============================
# Calibration Curve
# =============================

prob_true, prob_pred = calibration_curve(all_labels, all_probs, n_bins=10)

plt.figure()

plt.plot(prob_pred, prob_true, marker="o")

plt.plot([0,1],[0,1], "--")

plt.xlabel("Predicted Probability")
plt.ylabel("True Probability")

plt.title("Calibration Curve")

plt.savefig("calibration_curve.png")
plt.close()


# =============================
# Print Summary
# =============================

print("Graphs generated successfully:")
print("- performance_metrics.png")
print("- confusion_matrix.png")
print("- real_vs_fake_comparison.png")
print("- classwise_accuracy.png")
print("- roc_curve.png")
print("- precision_recall_curve.png")
print("- threshold_sensitivity.png")
print("- calibration_curve.png")

print(f"ROC AUC Score: {roc_auc:.4f}")