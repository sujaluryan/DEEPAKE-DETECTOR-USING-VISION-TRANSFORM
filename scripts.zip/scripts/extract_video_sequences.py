import cv2
import os

video_root = "data/raw"
output_root = "data_sequences"

categories = ["real", "fake"]

frame_skip = 5   # process every 5th frame

for category in categories:

    video_folder = os.path.join(video_root, category)

    for video_name in os.listdir(video_folder):

        video_path = os.path.join(video_folder, video_name)

        video_id = os.path.splitext(video_name)[0]

        save_dir = os.path.join(output_root, category, video_id)

        os.makedirs(save_dir, exist_ok=True)

        cap = cv2.VideoCapture(video_path)

        frame_count = 0
        saved_count = 0

        while True:

            ret, frame = cap.read()

            if not ret:
                break

            frame_count += 1

            if frame_count % frame_skip != 0:
                continue

            frame_filename = f"frame_{saved_count:04d}.jpg"

            frame_path = os.path.join(save_dir, frame_filename)

            cv2.imwrite(frame_path, frame)

            saved_count += 1

        cap.release()

        print(f"Processed {video_name} -> {saved_count} frames")

print("Frame extraction completed.")