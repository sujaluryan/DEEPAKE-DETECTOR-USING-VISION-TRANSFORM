import os
import shutil

source_dir = "data/faces"
target_dir = "data_sequences"

for category in ["real", "fake"]:

    category_path = os.path.join(source_dir, category)

    for file in os.listdir(category_path):

        if not file.endswith(".jpg"):
            continue

        # example filename: video1_frame_0001.jpg
        video_name = file.split("_frame")[0]

        video_folder = os.path.join(target_dir, category, video_name)

        os.makedirs(video_folder, exist_ok=True)

        src = os.path.join(category_path, file)
        dst = os.path.join(video_folder, file)

        shutil.copy(src, dst)

print("Dataset successfully reorganized into video sequences.")