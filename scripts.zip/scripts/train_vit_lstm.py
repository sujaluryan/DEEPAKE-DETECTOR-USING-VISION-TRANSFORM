import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from src.video_sequence_dataset import VideoSequenceDataset
from src.vit_lstm_model import ViTLSTM

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

dataset = VideoSequenceDataset("data_sequences", sequence_length=16)

loader = DataLoader(dataset, batch_size=4, shuffle=True)

model = ViTLSTM().to(device)

criterion = nn.CrossEntropyLoss()

optimizer = torch.optim.Adam(model.parameters(), lr=1e-4)

epochs = 10

for epoch in range(epochs):

    running_loss = 0

    for sequences, labels in loader:

        sequences = sequences.to(device)
        labels = labels.to(device)

        outputs = model(sequences)

        loss = criterion(outputs,labels)

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        running_loss += loss.item()

    print(f"Epoch {epoch+1}/{epochs} Loss: {running_loss}")