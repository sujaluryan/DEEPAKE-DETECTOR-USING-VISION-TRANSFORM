import os
import cv2
import csv
import argparse
from facenet_pytorch import MTCNN
from PIL import Image

def extract_faces(video_path, out_dir, mtcnn, fps=5, min_face=40, margin=0.2):
    os.makedirs(out_dir, exist_ok=True)
    vidcap = cv2.VideoCapture(video_path)
    if not vidcap.isOpened():
        print(f"[ERROR] Cannot open {video_path}")
        return 0
    
    total = int(vidcap.get(cv2.CAP_PROP_FRAME_COUNT))
    orig_fps = vidcap.get(cv2.CAP_PROP_FPS)
    interval = max(1, int(orig_fps / fps)) if orig_fps > 0 else 1

    frame_idx = 0
    saved = 0

    while True:
        ret, frame = vidcap.read()
        if not ret:
            break
        
        if frame_idx % interval == 0:
            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            img = Image.fromarray(rgb)

            boxes, _ = mtcnn.detect(img)

            if boxes is not None:
                for i, box in enumerate(boxes):
                    x1, y1, x2, y2 = [int(v) for v in box]
                    w, h = x2 - x1, y2 - y1
                    if min(w, h) < min_face:
                        continue
                    
                    crop = img.crop((x1, y1, x2, y2))
                    crop_name = f"{saved:06d}.jpg"
                    crop.save(os.path.join(out_dir, crop_name))
                    saved += 1

        frame_idx += 1

    vidcap.release()
    return saved


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input_dir", required=True)
    parser.add_argument("--output_dir", required=True)
    parser.add_argument("--fps", type=int, default=5)
    parser.add_argument("--min_face", type=int, default=40)
    parser.add_argument("--margin", type=float, default=0.2)
    parser.add_argument("--metadata", default="metadata_raw.csv")
    args = parser.parse_args()

    # load MTCNN
    mtcnn = MTCNN(keep_all=True, device="cpu")

    # load existing metadata
    done = set()
    if os.path.exists(args.metadata):
        with open(args.metadata, "r") as f:
            reader = csv.DictReader(f)
            for row in reader:
                done.add(row["video_id"])
        print(f"[INFO] Loaded {len(done)} completed videos from metadata.")
    else:
        print("[INFO] No metadata found, starting fresh.")

    all_videos = []
    for root, _, files in os.walk(args.input_dir):
        for f in files:
            if f.lower().endswith((".mp4", ".avi", ".mov", ".mkv")):
                full = os.path.join(root, f)
                vid_id = os.path.splitext(f)[0]
                all_videos.append((vid_id, full))

    print(f"[INFO] Found {len(all_videos)} total videos.")

    # open metadata for append
    new_file = not os.path.exists(args.metadata)
    with open(args.metadata, "a", newline="") as f:
        writer = csv.writer(f)
        if new_file:
            writer.writerow(["video_id", "video_path", "num_faces"])

        for vid_id, path in all_videos:
            if vid_id in done:
                print(f"[SKIP] {vid_id} already processed.")
                continue

            out_dir = os.path.join(args.output_dir, vid_id)
            print(f"[PROCESS] {vid_id}...")

            num = extract_faces(path, out_dir, mtcnn, fps=args.fps, min_face=args.min_face, margin=args.margin)
            print(f"[DONE] {vid_id}: {num} faces saved.")

            writer.writerow([vid_id, path, num])
            f.flush()


if __name__ == "__main__":
    main()
