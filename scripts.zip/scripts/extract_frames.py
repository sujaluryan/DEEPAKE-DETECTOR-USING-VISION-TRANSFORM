import cv2
import os

input_folder = "data/raw"
output_folder = "data/frames"

os.makedirs(output_folder, exist_ok=True)

for category in ["real", "fake"]:
    
    video_folder = os.path.join(input_folder, category)
    save_folder = os.path.join(output_folder, category)

    os.makedirs(save_folder, exist_ok=True)

    for video_name in os.listdir(video_folder):

        video_path = os.path.join(video_folder, video_name)
        cap = cv2.VideoCapture(video_path)

        frame_count = 0
        saved_count = 0

        while True:
            ret, frame = cap.read()

            if not ret:
                break

            # extract every 10th frame
            if frame_count % 10 == 0:
                frame_name = f"{video_name}_frame{saved_count}.jpg"
                cv2.imwrite(os.path.join(save_folder, frame_name), frame)
                saved_count += 1

            frame_count += 1

        cap.release()

print("Frame extraction completed!")