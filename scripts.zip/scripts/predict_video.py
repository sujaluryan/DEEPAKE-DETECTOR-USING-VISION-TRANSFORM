import torch
import torch.nn as nn
import timm
import cv2
from torchvision import transforms
from PIL import Image
import numpy as np

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# load model
model = timm.create_model("vit_base_patch16_224", pretrained=False)
model.head = nn.Linear(model.head.in_features, 2)

model.load_state_dict(torch.load("checkpoints/vit_deepfake_model.pth"))
model = model.to(device)
model.eval()

transform = transforms.Compose([
    transforms.Resize((224,224)),
    transforms.ToTensor()
])

video_path = "test_video.mp4"

cap = cv2.VideoCapture(video_path)

frame_probs = []

while True:
    ret, frame = cap.read()
    if not ret:
        break

    img = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    img = Image.fromarray(img)

    img = transform(img).unsqueeze(0).to(device)

    with torch.no_grad():
        output = model(img)
        prob = torch.softmax(output, dim=1)[0][1].item()

    frame_probs.append(prob)

cap.release()

# video level prediction
video_score = np.mean(frame_probs)

print("Video deepfake probability:", video_score)

if video_score > 0.5:
    print("Prediction: FAKE")
else:
    print("Prediction: REAL")