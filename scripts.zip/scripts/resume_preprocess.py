# scripts/resume_preprocess.py
import os, sys, argparse, csv, hashlib
from pathlib import Path
from tqdm import tqdm
import cv2
from PIL import Image
import numpy as np

# facenet_pytorch import (MTCNN)
try:
    from facenet_pytorch import MTCNN
except Exception as e:
    print("facenet_pytorch import error:", e)
    print("Make sure your venv has facenet-pytorch and torch installed.")
    raise

def video_basename(path):
    return Path(path).stem

def ensure_dir(p):
    Path(p).mkdir(parents=True, exist_ok=True)

def count_existing_crops(out_dir, video_name):
    # convention: crops stored under out_dir/<video_name>/ or filenames containing video_name
    d = Path(out_dir) / video_name
    if d.exists() and d.is_dir():
        return len(list(d.glob("*.jpg")))
    # fallback: count files that contain video_name in their filename
    files = list(Path(out_dir).rglob(f"*{video_name}*.jpg"))
    return len(files)

def append_csv_row(csv_path, row):
    # append a row atomically
    header_needed = not Path(csv_path).exists()
    with open(csv_path, "a", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        if header_needed:
            writer.writerow(["path","label","video_id","orig_id","frame_no"])
        writer.writerow(row)

def process_video(video_path, out_dir, mtcnn, fps, min_face, margin, label, video_id, orig_id, csv_path):
    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        print("Cannot open video:", video_path)
        return 0
    input_fps = cap.get(cv2.CAP_PROP_FPS) or 25.0
    frame_interval = max(1, int(round(input_fps / fps)))
    frame_idx = 0
    saved = 0
    video_name = video_basename(video_path)
    save_dir = Path(out_dir) / video_name
    ensure_dir(save_dir)
    pbar = tqdm(total=int(cap.get(cv2.CAP_PROP_FRAME_COUNT)), desc=f"Proc {video_name}", unit="f")
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        if frame_idx % frame_interval == 0:
            # BGR->RGB
            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            img = Image.fromarray(rgb)
            # Detect faces
            boxes, _ = mtcnn.detect(img)
            if boxes is not None:
                for i, box in enumerate(boxes):
                    x1, y1, x2, y2 = [int(max(0, v)) for v in box]
                    w = x2 - x1
                    h = y2 - y1
                    if w < min_face or h < min_face:
                        continue
                    # add margin
                    mx = int(w * margin)
                    my = int(h * margin)
                    x1m = max(0, x1 - mx)
                    y1m = max(0, y1 - my)
                    x2m = min(img.width, x2 + mx)
                    y2m = min(img.height, y2 + my)
                    crop = img.crop((x1m, y1m, x2m, y2m)).convert("RGB")
                    fname = f"{video_name}_f{frame_idx:06d}_c{i}.jpg"
                    out_path = save_dir / fname
                    crop.save(out_path, format="JPEG", quality=95)
                    # CSV row: path (relative), label, video_id, orig_id, frame_no
                    rel_path = str(Path(out_dir).joinpath(video_name, fname)).replace("\\","/")
                    append_csv_row(csv_path, [rel_path, label, video_id, orig_id, frame_idx])
                    saved += 1
        frame_idx += 1
        pbar.update(1)
    pbar.close()
    cap.release()
    return saved

def find_videos(input_dir):
    p = Path(input_dir)
    vids = list(p.rglob("*.mp4")) + list(p.rglob("*.mov")) + list(p.rglob("*.mkv"))
    return sorted([str(x) for x in vids])

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input_dir", required=True)   # e.g., data/raw/myset
    ap.add_argument("--output_dir", required=True)  # e.g., data/processed/myset_faces
    ap.add_argument("--fps", type=float, default=5.0)
    ap.add_argument("--min_face", type=int, default=40)
    ap.add_argument("--margin", type=float, default=0.3)
    ap.add_argument("--metadata", default="data/processed/myset_faces/metadata_raw.csv")
    ap.add_argument("--label_map", default=None, help="optional csv mapping video_path->label,video_id,orig_id")
    args = ap.parse_args()

    mtcnn = MTCNN(keep_all=True, device='cpu')

    videos = find_videos(args.input_dir)
    print(f"Found {len(videos)} videos under {args.input_dir}")

    # load label_map if provided (csv with columns path,label,video_id,orig_id). If not, infer from path segments
    label_map = {}
    if args.label_map and os.path.exists(args.label_map):
        import pandas as pd
        df = pd.read_csv(args.label_map)
        for _, r in df.iterrows():
            label_map[str(r['path'])] = (r.get('label'), r.get('video_id'), r.get('orig_id'))

    for v in videos:
        # infer label from containing folder name if not provided
        parts = Path(v).parts
        # try to find 'real' or 'fake' in the path
        lower = v.lower()
        label = "unknown"
        if "/real/" in lower or "\\real\\" in lower:
            label = "real"
        elif "/fake/" in lower or "\\fake\\" in lower:
            label = "fake"
        video_name = video_basename(v)
        existing = count_existing_crops(args.output_dir, video_name)
        if existing >= 10:
            # heuristic: if already >10 crops, skip video
            print(f"Skipping {video_name} — {existing} crops found")
            continue
        # get ids from label_map if present
        vid, orig = None, None
        key = v
        if key in label_map:
            label, vid, orig = label_map[key]
        else:
            # fallback IDs: use filename as video_id, orig_id as filename prefix
            vid = video_name
            orig = video_name.split("_")[0] if "_" in video_name else video_name

        print(f"Processing {v} -> label={label} video_id={vid} orig_id={orig}")
        saved = process_video(v, args.output_dir, mtcnn, args.fps, args.min_face, args.margin, label, vid, orig, args.metadata)
        print(f"Saved {saved} crops for {video_name}")

if __name__ == "__main__":
    main()
