import os
import shutil
import random

source = "data/faces"

train_dir = "data_split/train"
val_dir = "data_split/val"
test_dir = "data_split/test"

split_ratio = (0.8, 0.1, 0.1)

for category in ["real", "fake"]:

    images = os.listdir(os.path.join(source, category))
    random.shuffle(images)

    total = len(images)

    train_end = int(split_ratio[0] * total)
    val_end = train_end + int(split_ratio[1] * total)

    train_images = images[:train_end]
    val_images = images[train_end:val_end]
    test_images = images[val_end:]

    for folder, img_list in zip(
        [train_dir, val_dir, test_dir],
        [train_images, val_images, test_images]
    ):

        os.makedirs(os.path.join(folder, category), exist_ok=True)

        for img in img_list:

            src = os.path.join(source, category, img)
            dst = os.path.join(folder, category, img)

            shutil.copy(src, dst)

print("Dataset split completed!")