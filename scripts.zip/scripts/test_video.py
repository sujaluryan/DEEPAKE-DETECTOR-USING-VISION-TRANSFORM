import torch
import torch.nn as nn
import timm
import cv2
import numpy as np
from torchvision import transforms
from PIL import Image
from insightface.app import FaceAnalysis

# ===============================
# DEVICE
# ===============================
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print("Using device:", device)

# ===============================
# LOAD TRAINED MODEL
# ===============================
model = timm.create_model("vit_base_patch16_224", pretrained=False)
model.head = nn.Linear(model.head.in_features, 2)

model.load_state_dict(torch.load("checkpoints/vit_deepfake_model.pth", map_location=device))
model = model.to(device)
model.eval()

# ===============================
# IMAGE TRANSFORM
# ===============================
transform = transforms.Compose([
    transforms.Resize((224,224)),
    transforms.ToTensor()
])

# ===============================
# FACE DETECTOR
# ===============================
face_detector = FaceAnalysis(name="buffalo_l")
face_detector.prepare(ctx_id=0 if torch.cuda.is_available() else -1)

# ===============================
# VIDEO PATH
# ===============================
video_path = "test_video.mp4"

cap = cv2.VideoCapture(video_path)

frame_probs = []

print("Processing video...")

while True:

    ret, frame = cap.read()

    if not ret:
        break

    faces = face_detector.get(frame)

    if len(faces) == 0:
        continue

    # take first detected face
    bbox = faces[0].bbox.astype(int)

    x1, y1, x2, y2 = bbox

    face = frame[y1:y2, x1:x2]

    if face.size == 0:
        continue

    face = cv2.cvtColor(face, cv2.COLOR_BGR2RGB)

    img = Image.fromarray(face)

    img = transform(img).unsqueeze(0).to(device)

    with torch.no_grad():

        output = model(img)

        prob = torch.softmax(output, dim=1)[0][1].item()

    frame_probs.append(prob)

cap.release()

# ===============================
# VIDEO LEVEL PREDICTION
# ===============================
if len(frame_probs) == 0:

    print("No faces detected in video.")

else:

    video_score = np.mean(frame_probs)

    print("\nDeepfake probability:", video_score)

    if video_score > 0.5:
        print("Prediction: FAKE")
    else:
        print("Prediction: REAL")