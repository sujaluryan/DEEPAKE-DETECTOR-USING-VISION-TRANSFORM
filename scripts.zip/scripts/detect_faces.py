import os
from PIL import Image
from facenet_pytorch import MTCNN

input_folder = "data/frames"
output_folder = "data/faces"

mtcnn = MTCNN(image_size=224, margin=20)

os.makedirs(output_folder, exist_ok=True)

for category in ["real", "fake"]:

    frame_folder = os.path.join(input_folder, category)
    face_folder = os.path.join(output_folder, category)

    os.makedirs(face_folder, exist_ok=True)

    for image_name in os.listdir(frame_folder):

        img_path = os.path.join(frame_folder, image_name)

        try:
            img = Image.open(img_path)

            face = mtcnn(img)

            if face is not None:

                save_path = os.path.join(face_folder, image_name)

                face_image = face.permute(1,2,0).numpy()*255
                face_image = face_image.astype("uint8")

                Image.fromarray(face_image).save(save_path)

        except:
            continue

print("Face extraction completed!")
