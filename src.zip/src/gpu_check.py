import torch
print("CUDA:", torch.cuda.is_available(), "count:", torch.cuda.device_count())
print("Device:", torch.cuda.get_device_name(0) if torch.cuda.is_available() else "none")
