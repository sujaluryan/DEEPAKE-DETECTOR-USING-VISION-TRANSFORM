# src/preprocess.py  — OpenCV Haar face-cropper (no MTCNN)
import os
import glob
import cv2
import argparse
import pandas as pd
from tqdm import tqdm
from PIL import Image

def extract_faces_from_video(video_path, output_dir, fps=5, min_face=60, margin=0.2):
    """
    Extract face crops from a video using OpenCV's Haar cascade.
    Saves crops into output_dir and returns list of saved file paths.
    """
    face_cascade = cv2.CascadeClassifier(
        cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
    )

    os.makedirs(output_dir, exist_ok=True)
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        print(f"[WARN] Could not open {video_path}")
        return []

    vid = os.path.splitext(os.path.basename(video_path))[0]
    faces_saved = []

    input_fps = cap.get(cv2.CAP_PROP_FPS) or 25.0
    step = max(1, int(round(input_fps / max(1, fps))))
    frame_idx = 0

    while True:
        ret, frame = cap.read()
        if not ret:
            break
        if frame_idx % step == 0:
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            dets = face_cascade.detectMultiScale(
                gray,
                scaleFactor=1.1,
                minNeighbors=5,
                flags=cv2.CASCADE_SCALE_IMAGE,
                minSize=(min_face, min_face),
            )
            for bi, (x, y, w, h) in enumerate(dets):
                # add margin
                mx, my = int(margin * w), int(margin * h)
                x1 = max(0, x - mx); y1 = max(0, y - my)
                x2 = min(frame.shape[1], x + w + mx); y2 = min(frame.shape[0], y + h + my)

                crop_bgr = frame[y1:y2, x1:x2]
                if crop_bgr.size == 0:
                    continue
                crop = cv2.cvtColor(crop_bgr, cv2.COLOR_BGR2RGB)
                out_path = os.path.join(output_dir, f"{vid}_f{frame_idx:06d}_face{bi}.jpg")
                Image.fromarray(crop).save(out_path, quality=95)
                faces_saved.append(out_path)
        frame_idx += 1

    cap.release()
    return faces_saved

def main():
    ap = argparse.ArgumentParser(description="Video → face crops (OpenCV Haar) + CSV")
    ap.add_argument("--input_dir", required=True, help="Contains subfolders for real/ and fake/ videos")
    ap.add_argument("--output_dir", required=True, help="Where to write face crops")
    ap.add_argument("--fps", type=int, default=5, help="Frames per second to sample")
    ap.add_argument("--min_face", type=int, default=60, help="Minimum face size in pixels")
    ap.add_argument("--margin", type=float, default=0.2, help="Margin around detected face (0–0.5)")
    ap.add_argument("--real_subdir", type=str, default="real", help="Name of real subfolder")
    ap.add_argument("--fake_subdir", type=str, default="fake", help="Name of fake subfolder")
    ap.add_argument("--write_csv", type=str, default=None, help="CSV path to write (path,label,video_id)")
    args = ap.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)
    rows = []

    for label, sub in [(0, args.real_subdir), (1, args.fake_subdir)]:
        src = os.path.join(args.input_dir, sub)
        if not os.path.isdir(src):
            print(f"[WARN] Missing folder: {src}, skipping.")
            continue

        videos = sorted(
            glob.glob(os.path.join(src, "*.mp4"))
            + glob.glob(os.path.join(src, "*.avi"))
            + glob.glob(os.path.join(src, "*.mov"))
        )
        print(f"[INFO] Found {len(videos)} videos in {src}")
        for vp in tqdm(videos, desc=f"Processing {sub}"):
            vid = os.path.splitext(os.path.basename(vp))[0]
            out_dir_vid = os.path.join(args.output_dir, vid)
            os.makedirs(out_dir_vid, exist_ok=True)
            faces = extract_faces_from_video(
                vp, out_dir_vid, fps=args.fps, min_face=args.min_face, margin=args.margin
            )
            for fp in faces:
                rows.append({"path": fp, "label": label, "video_id": vid})

    if args.write_csv:
        if len(rows) == 0:
            print(f"[WARN] No faces saved. CSV not written: {args.write_csv}")
        else:
            df = pd.DataFrame(rows)
            df.to_csv(args.write_csv, index=False)
            print(f"[OK] Wrote CSV: {args.write_csv}  (rows={len(rows)})")

if __name__ == "__main__":
    main()
