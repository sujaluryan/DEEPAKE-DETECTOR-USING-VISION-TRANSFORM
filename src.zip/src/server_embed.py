# src/server_embed.py — FastAPI: Haar face extraction + ResNet50 embeddings + Logistic Regression
import os
import tempfile
import shutil
from typing import List

import numpy as np
import torch
import joblib

from fastapi import FastAPI, UploadFile, File
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware

from PIL import Image
from torchvision import models, transforms

# Reuse your Haar-based extractor from preprocess.py
# (Make sure preprocess.py is in src/ and contains extract_faces_from_video)
from src.preprocess import extract_faces_from_video

app = FastAPI(title="Deepfake Detector (ResNet50 Embeddings + LR)")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],   # for local demo; tighten later if needed
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# -------- Config (env overrides) --------
CLF_PATH = os.environ.get("EMB_CLF", "checkpoints/emb_lr.pkl")  # joblib classifier path
BATCH = int(os.environ.get("EMB_BATCH", "64"))
FPS = int(os.environ.get("EMB_FPS", "10"))          # frames sampled during face extraction
MIN_FACE = int(os.environ.get("EMB_MIN_FACE", "40"))  # smaller → more faces, faster saturation
MARGIN = float(os.environ.get("EMB_MARGIN", "0.3"))
MAX_FACES = int(os.environ.get("EMB_MAX_FACES", "600"))  # hard cap per request to avoid long runs

# Select device (CPU is fine for this pipeline)
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

# -------- Load backbone & transforms (pretrained) --------
model_backbone = models.resnet50(weights=models.ResNet50_Weights.IMAGENET1K_V2)
model_backbone.fc = torch.nn.Identity()  # 2048-D embeddings
model_backbone.eval().to(DEVICE)

tfm = transforms.Compose([
    transforms.Resize(256), transforms.CenterCrop(224),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406],
                         std=[0.229, 0.224, 0.225]),
])

# Will be loaded at startup
clf = None  # type: ignore


@app.on_event("startup")
def _load_classifier():
    global clf
    clf = joblib.load(CLF_PATH)
    print(f"[READY] Loaded classifier: {CLF_PATH} | device={DEVICE}")


@app.get("/health")
def health():
    exists = os.path.exists(CLF_PATH)
    return {"status": "ok" if exists else "missing-clf", "clf": CLF_PATH, "device": DEVICE}


def _embed_paths(paths: List[str]) -> np.ndarray:
    """Load images from file paths, run through ResNet50, return (N, 2048) embeddings."""
    embs = []
    batch = []
    with torch.no_grad():
        for i, p in enumerate(paths):
            try:
                im = Image.open(p).convert("RGB")
            except Exception:
                # skip unreadable files silently
                continue
            batch.append(tfm(im))

            if len(batch) == BATCH:
                x = torch.stack(batch).to(DEVICE)
                z = model_backbone(x).cpu().numpy()
                embs.append(z)
                batch = []
        if batch:
            x = torch.stack(batch).to(DEVICE)
            z = model_backbone(x).cpu().numpy()
            embs.append(z)

    if not embs:
        return np.zeros((0, 2048), dtype=np.float32)
    return np.concatenate(embs, axis=0)


@app.post("/predict/video")
def predict_video_endpoint(video: UploadFile = File(...)):
    """
    Upload a video → extract faces with Haar → ResNet50 embeddings → LR classifier → %
    Returns: fake_percentage, real_percentage, frames_used, verdict
    """
    # Save upload to a secure temp file
    with tempfile.NamedTemporaryFile(delete=False, suffix=os.path.splitext(video.filename)[1]) as tmp:
        tmp_path = tmp.name
        shutil.copyfileobj(video.file, tmp)

    # Prepare a temp directory for face crops
    tmp_dir = tempfile.mkdtemp(prefix="faces_")

    try:
        # 1) Extract face crops
        faces = extract_faces_from_video(
            video_path=tmp_path,
            output_dir=tmp_dir,
            fps=FPS,
            min_face=MIN_FACE,
            margin=MARGIN
        )

        # Cap the number of faces per request for responsiveness
        if len(faces) > MAX_FACES:
            faces = faces[:MAX_FACES]

        if not faces:
            return JSONResponse({
                "fake_percentage": 0.0,
                "real_percentage": 100.0,
                "frames_used": 0,
                "verdict": "REAL",
                "note": "no faces detected"
            })

        # 2) Embeddings
        X = _embed_paths(faces)  # shape (N, 2048)

        if X.shape[0] == 0:
            return JSONResponse({
                "fake_percentage": 0.0,
                "real_percentage": 100.0,
                "frames_used": 0,
                "verdict": "REAL",
                "note": "no readable crops"
            })

        # 3) Classifier probabilities (LogReg with predict_proba)
        probs = clf.predict_proba(X)[:, 1]  # probability of FAKE

        # 4) Aggregate → percentages + verdict
        mean_fake = float(np.mean(probs))
        fake_pct = round(mean_fake * 100.0, 2)
        real_pct = round(100.0 - fake_pct, 2)
        verdict = "FAKE" if fake_pct > 50.0 else "REAL"

        return JSONResponse({
            "fake_percentage": fake_pct,
            "real_percentage": real_pct,
            "frames_used": int(len(probs)),
            "verdict": verdict
        })

    finally:
        # Cleanup temp artifacts
        try:
            os.remove(tmp_path)
        except Exception:
            pass
        try:
            shutil.rmtree(tmp_dir, ignore_errors=True)
        except Exception:
            pass
