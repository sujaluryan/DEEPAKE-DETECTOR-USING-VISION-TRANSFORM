import pandas as pd
from PIL import Image
from torch.utils.data import Dataset
from torchvision import transforms

class FaceCropDataset(Dataset):
    """
    Expects a CSV with columns: path,label,video_id
    - path: filesystem path to an image (face crop)
    - label: 0 (real) or 1 (fake)
    - video_id: grouping key for aggregation (string or numeric)
    """
    def __init__(self, csv_path, img_size=299, augment=False):
        self.df = pd.read_csv(csv_path)
        self.img_size = img_size
        if augment:
            self.tf = transforms.Compose([
                transforms.RandomHorizontalFlip(),
                transforms.RandomResizedCrop(img_size, scale=(0.9,1.0)),
                transforms.ColorJitter(brightness=0.1, contrast=0.1, saturation=0.1, hue=0.02),
                transforms.ToTensor()
            ])
        else:
            self.tf = transforms.Compose([
                transforms.Resize((img_size, img_size)),
                transforms.ToTensor()
            ])

    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx):
        row = self.df.iloc[idx]
        path = row["path"]
        label = int(row["label"])
        vid = str(row["video_id"])
        img = Image.open(path).convert("RGB")
        img = self.tf(img)
        return img, label, vid
