import torch
import torch.nn as nn
import timm

class XceptionDetector(nn.Module):
    def __init__(self, model_name="xception", num_classes=1, pretrained=True):
        super().__init__()
        self.backbone = timm.create_model(model_name, pretrained=pretrained, num_classes=0, global_pool="avg")
        in_feats = self.backbone.num_features
        self.head = nn.Linear(in_feats, num_classes)
    
    def forward(self, x):
        feats = self.backbone(x)         # (B, F)
        logits = self.head(feats).squeeze(-1)  # (B,)
        return logits
