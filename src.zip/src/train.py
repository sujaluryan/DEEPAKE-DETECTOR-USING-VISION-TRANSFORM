import os
import argparse
import pandas as pd
import numpy as np
from tqdm import tqdm
from sklearn.model_selection import train_test_split

import torch
import torch.nn as nn
from torch.utils.data import DataLoader

from datasets import FaceCropDataset
from models import XceptionDetector
from utils import set_seed, ensure_dir, AverageMeter, auc_roc, accuracy, collate_with_vid, timestamp

def save_checkpoint(state, is_best, out_dir):
    ensure_dir(out_dir)
    last_path = os.path.join(out_dir, "last.pt")
    torch.save(state, last_path)
    if is_best:
        best_path = os.path.join(out_dir, "best.pt")
        torch.save(state, best_path)

def train_one_epoch(model, loader, optimizer, scaler, device, criterion):
    model.train()
    loss_meter = AverageMeter()

    for imgs, labels, vids in tqdm(loader, desc="train", leave=False):
        imgs = imgs.to(device, non_blocking=True)
        labels = labels.float().to(device, non_blocking=True)

        optimizer.zero_grad(set_to_none=True)
        with torch.cuda.amp.autocast(enabled=(device.type == "cuda")):
            logits = model(imgs)
            loss = criterion(logits, labels)
        scaler.scale(loss).backward()
        scaler.step(optimizer)
        scaler.update()

        loss_meter.update(loss.item(), n=imgs.size(0))
    return loss_meter.avg

@torch.no_grad()
def evaluate(model, loader, device, criterion):
    model.eval()
    loss_meter = AverageMeter()
    all_probs, all_labels = [], []

    for imgs, labels, vids in tqdm(loader, desc="val", leave=False):
        imgs = imgs.to(device, non_blocking=True)
        labels = labels.float().to(device, non_blocking=True)
        logits = model(imgs)
        loss = criterion(logits, labels)
        probs = torch.sigmoid(logits).detach().cpu().numpy()
        all_probs.extend(probs.tolist())
        all_labels.extend(labels.detach().cpu().numpy().tolist())
        loss_meter.update(loss.item(), n=imgs.size(0))

    import numpy as np
    all_probs = np.array(all_probs)
    all_labels = np.array(all_labels)
    auc = auc_roc(all_labels, all_probs)
    acc = accuracy(all_labels, all_probs)
    return loss_meter.avg, auc, acc

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv_train", type=str, required=True, help="CSV with columns path,label,video_id")
    ap.add_argument("--csv_val", type=str, default=None, help="Optional separate val CSV; else split from train")
    ap.add_argument("--val_split", type=float, default=0.1, help="If csv_val not provided, split ratio")
    ap.add_argument("--out_dir", type=str, required=True)
    ap.add_argument("--model", type=str, default="xception")
    ap.add_argument("--img_size", type=int, default=299)
    ap.add_argument("--batch_size", type=int, default=32)
    ap.add_argument("--epochs", type=int, default=10)
    ap.add_argument("--lr", type=float, default=3e-4)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--num_workers", type=int, default=4)
    args = ap.parse_args()

    set_seed(args.seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    ensure_dir(args.out_dir)

    # Load CSVs
    df = pd.read_csv(args.csv_train)
    if args.csv_val is None:
        tr, va = train_test_split(df, test_size=args.val_split, stratify=df["label"], random_state=args.seed)
        csv_train_tmp = os.path.join(args.out_dir, f"train_split_{timestamp()}.csv")
        csv_val_tmp = os.path.join(args.out_dir, f"val_split_{timestamp()}.csv")
        tr.to_csv(csv_train_tmp, index=False); va.to_csv(csv_val_tmp, index=False)
        train_csv = csv_train_tmp; val_csv = csv_val_tmp
    else:
        train_csv = args.csv_train; val_csv = args.csv_val

    # Datasets / Loaders
    ds_train = FaceCropDataset(train_csv, img_size=args.img_size, augment=True)
    ds_val   = FaceCropDataset(val_csv, img_size=args.img_size, augment=False)

    dl_train = DataLoader(ds_train, batch_size=args.batch_size, shuffle=True, num_workers=args.num_workers, pin_memory=True, collate_fn=collate_with_vid)
    dl_val   = DataLoader(ds_val, batch_size=args.batch_size, shuffle=False, num_workers=args.num_workers, pin_memory=True, collate_fn=collate_with_vid)

    # Model
    model = XceptionDetector(model_name=args.model, pretrained=True)
    model.to(device)

    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=1e-4)
    scaler = torch.cuda.amp.GradScaler(enabled=(device.type == "cuda"))
    criterion = nn.BCEWithLogitsLoss()

    best_auc = -1
    for epoch in range(1, args.epochs + 1):
        print(f"Epoch {epoch}/{args.epochs}")
        tr_loss = train_one_epoch(model, dl_train, optimizer, scaler, device, criterion)
        val_loss, val_auc, val_acc = evaluate(model, dl_val, device, criterion)
        print(f"[val] loss={val_loss:.4f} AUC={val_auc:.4f} ACC={val_acc:.4f}")

        save_checkpoint({
            "epoch": epoch,
            "model_state": model.state_dict(),
            "optimizer_state": optimizer.state_dict(),
            "scaler_state": scaler.state_dict(),
            "val_auc": val_auc,
            "val_loss": val_loss,
            "args": vars(args),
        }, is_best=(val_auc > best_auc), out_dir=args.out_dir)

        if val_auc > best_auc:
            best_auc = val_auc

if __name__ == "__main__":
    main()
