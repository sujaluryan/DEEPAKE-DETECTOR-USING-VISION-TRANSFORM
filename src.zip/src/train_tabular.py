#!/usr/bin/env python3
# src/train_tabular.py
"""
Train a simple classifier on saved embeddings .npz
Outputs a joblib pickle with the trained model and scaler.
"""

import argparse, os
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold, cross_val_score
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import roc_auc_score
import joblib

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--npz", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--model", default="logistic", choices=["logistic"])
    ap.add_argument("--cv", type=int, default=5)
    ap.add_argument("--C", type=float, default=1.0)
    args = ap.parse_args()

    data = np.load(args.npz, allow_pickle=True)
    X = data['embeddings']
    y = data['labels']
    print(f"[train_tab] loaded X={X.shape} y={y.shape}")

    scaler = StandardScaler()
    Xs = scaler.fit_transform(X)

    clf = LogisticRegression(C=args.C, class_weight='balanced', max_iter=2000, solver='lbfgs')
    if args.cv > 1:
        cv = StratifiedKFold(n_splits=args.cv, shuffle=True, random_state=42)
        scores = cross_val_score(clf, Xs, y, cv=cv, scoring='roc_auc', n_jobs=-1)
        print(f"[train_tab] CV AUCs: {scores} mean={scores.mean():.4f} std={scores.std():.4f}")

    clf.fit(Xs, y)
    os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)
    joblib.dump({"scaler": scaler, "clf": clf}, args.out)
    print(f"[train_tab] saved model to {args.out}")

if __name__ == "__main__":
    main()
