# src/infer.py — Video inference with OpenCV Haar + timm Xception
import os
import argparse
import cv2
import torch
import timm
import numpy as np
from PIL import Image
from torchvision import transforms

# ---------- Face detection (OpenCV Haar) ----------
_FACE_CASCADE = cv2.CascadeClassifier(
    cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
)

def detect_face_crops(frame_bgr, min_face=60, margin=0.2):
    """
    Returns a list of PIL RGB crops for faces found in a BGR frame.
    """
    gray = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2GRAY)
    dets = _FACE_CASCADE.detectMultiScale(
        gray, scaleFactor=1.1, minNeighbors=5,
        flags=cv2.CASCADE_SCALE_IMAGE, minSize=(min_face, min_face)
    )
    crops = []
    H, W = frame_bgr.shape[:2]
    for (x, y, w, h) in dets:
        mx, my = int(margin * w), int(margin * h)
        x1 = max(0, x - mx); y1 = max(0, y - my)
        x2 = min(W, x + w + mx); y2 = min(H, y + h + my)
        if x2 > x1 and y2 > y1:
            rgb = cv2.cvtColor(frame_bgr[y1:y2, x1:x2], cv2.COLOR_BGR2RGB)
            crops.append(Image.fromarray(rgb))
    return crops

# ---------- Model / transforms ----------
def build_model(img_size=299, num_classes=1, pretrained=True):
    """
    Builds Xception (legacy) from timm and adapts classifier.
    num_classes:
      - 1  → BCEWithLogits-style single logit (sigmoid at inference)
      - 2  → softmax 2-way
    """
    # timm maps 'xception' → 'legacy_xception' internally (warning is normal)
    model = timm.create_model("xception", pretrained=pretrained, num_classes=num_classes)
    return model

def build_transform(img_size=299):
    return transforms.Compose([
        transforms.Resize((img_size, img_size)),
        transforms.ToTensor(),
        transforms.Normalize(
            mean=[0.485, 0.456, 0.406],
            std =[0.229, 0.224, 0.225],
        ),
    ])

# ---------- Prediction ----------
@torch.no_grad()
def predict_video(video_path, model, tf, device="cpu", every_n=1, min_face=60, margin=0.2, max_frames=None):
    """
    Runs face detection on frames (sampling every_n), scores each face crop,
    returns (mean_prob_fake, list_of_probs).
    """
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        raise RuntimeError(f"Could not open video: {video_path}")

    scores = []
    frame_idx = 0
    processed = 0

    while True:
        ok, frame_bgr = cap.read()
        if not ok:
            break
        frame_idx += 1
        if frame_idx % every_n != 0:
            continue

        crops = detect_face_crops(frame_bgr, min_face=min_face, margin=margin)
        if not crops:
            continue

        for crop in crops:
            x = tf(crop).unsqueeze(0).to(device)
            y = model(x)

            # Support 1-logit (BCE) or 2-class (softmax) heads
            if y.ndim == 2 and y.shape[1] == 1:
                prob_fake = torch.sigmoid(y)[0, 0].item()
            elif y.ndim == 2 and y.shape[1] == 2:
                prob_fake = torch.softmax(y, dim=1)[0, 1].item()
            else:
                # Fallback: treat scalar
                prob_fake = torch.sigmoid(y.view(1)).item()

            scores.append(prob_fake)

        processed += 1
        if max_frames is not None and processed >= max_frames:
            break

    cap.release()

    if len(scores) == 0:
        print("[WARN] No faces detected in any sampled frame.")
        return 0.0, []

    mean_score = float(np.mean(scores))
    print(f"[Video] frames_used={len(scores)}  mean_prob_fake={mean_score:.4f}")
    return mean_score, scores

# ---------- Checkpoint load ----------
def load_checkpoint_into_model(model, ckpt_path, map_location):
    ckpt = torch.load(ckpt_path, map_location=map_location)
    state = ckpt.get("model", ckpt)  # support either {'model': state_dict} or plain state_dict
    # Some training scripts save with different heads; try strict=False
    missing, unexpected = model.load_state_dict(state, strict=False)
    if missing or unexpected:
        print(f"[INFO] load_state_dict: missing={len(missing)} unexpected={len(unexpected)}")
    return model

# ---------- CLI ----------
def main():
    ap = argparse.ArgumentParser(description="Deepfake inference with Haar + Xception")
    ap.add_argument("--video", required=True, help="Path to input video (mp4/avi/mov)")
    ap.add_argument("--checkpoint", required=True, help="Path to model checkpoint (best.pt)")
    ap.add_argument("--img_size", type=int, default=299, help="Input size for model")
    ap.add_argument("--every_n", type=int, default=1, help="Sample every Nth frame (1 = use all)")
    ap.add_argument("--min_face", type=int, default=60, help="Minimum detected face size (pixels)")
    ap.add_argument("--margin", type=float, default=0.2, help="Crop margin around face [0..0.5]")
    ap.add_argument("--max_frames", type=int, default=None, help="Optional cap on sampled frames")
    ap.add_argument("--cpu", action="store_true", help="Force CPU even if CUDA is available")
    args = ap.parse_args()

    device = torch.device("cpu" if args.cpu or not torch.cuda.is_available() else "cuda")
    print(f"[INFO] Using device: {device}")

    # If your training used 1-logit output (default in our starter), keep num_classes=1.
    # If you trained a 2-class head, change to num_classes=2.
    model = build_model(img_size=args.img_size, num_classes=1, pretrained=False).to(device)
    model = load_checkpoint_into_model(model, args.checkpoint, map_location=device)
    model.eval()

    tf = build_transform(img_size=args.img_size)

    mean_score, _ = predict_video(
        video_path=args.video,
        model=model,
        tf=tf,
        device=device,
        every_n=args.every_n,
        min_face=args.min_face,
        margin=args.margin,
        max_frames=args.max_frames,
    )
    # Print a simple JSON-like line (handy for scripts)
    print({"video": args.video, "mean_prob_fake": round(mean_score, 4)})

if __name__ == "__main__":
    main()
