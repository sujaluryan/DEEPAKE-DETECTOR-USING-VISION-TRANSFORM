import torch
import torch.nn as nn
import timm

class ViTLSTM(nn.Module):

    def __init__(self, num_classes=2, hidden_size=512):

        super(ViTLSTM, self).__init__()

        # Vision Transformer
        self.vit = timm.create_model("vit_base_patch16_224", pretrained=True)

        feature_dim = self.vit.head.in_features

        # remove classification head
        self.vit.head = nn.Identity()

        # LSTM for temporal modeling
        self.lstm = nn.LSTM(
            input_size=feature_dim,
            hidden_size=hidden_size,
            num_layers=2,
            batch_first=True
        )

        # final classifier
        self.fc = nn.Linear(hidden_size, num_classes)

    def forward(self, x):

        B, T, C, H, W = x.shape

        # reshape for ViT
        x = x.view(B*T, C, H, W)

        features = self.vit(x)

        features = features.view(B, T, -1)

        lstm_out, _ = self.lstm(features)

        final_feature = lstm_out[:, -1, :]

        output = self.fc(final_feature)

        return output