import os, argparse, glob, numpy as np, torch, joblib
from PIL import Image
from torchvision import models, transforms

def load_backbone(device):
    m = models.resnet50(weights=models.ResNet50_Weights.IMAGENET1K_V2)
    m.fc = torch.nn.Identity()
    m.eval().to(device)
    tfm = transforms.Compose([
        transforms.Resize(256), transforms.CenterCrop(224),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485,0.456,0.406], std=[0.229,0.224,0.225]),
    ])
    return m, tfm

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--faces_dir", required=True, help="face crops folder for one video")
    ap.add_argument("--clf", required=True, help="joblib pkl from train_tabular")
    ap.add_argument("--batch", type=int, default=64)
    args = ap.parse_args()

    device = "cuda" if torch.cuda.is_available() else "cpu"
    model, tfm = load_backbone(device)
    clf = joblib.load(args.clf)

    imgs = sorted(glob.glob(os.path.join(args.faces_dir, "*.jpg")))
    if not imgs:
        print("[WARN] no face crops found"); return
    embs, batch = [], []
    with torch.no_grad():
        for p in imgs:
            try:
                im = Image.open(p).convert("RGB")
            except:
                continue
            batch.append(tfm(im))
            if len(batch) == args.batch:
                x = torch.stack(batch).to(device)
                z = model(x).cpu().numpy()
                embs.append(z); batch=[]
        if batch:
            x = torch.stack(batch).to(device)
            z = model(x).cpu().numpy()
            embs.append(z)

    X = np.concatenate(embs, axis=0)
    probs = clf.predict_proba(X)[:, 1]
    print(f"[Video] frames_used={len(probs)}  mean_prob_fake={probs.mean():.4f}")

if __name__ == "__main__":
    main()
