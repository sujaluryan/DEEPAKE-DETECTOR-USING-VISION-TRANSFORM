# src/server_infer.py — FastAPI for deepfake scoring (Haar + Xception)
import os, tempfile, shutil
from fastapi import FastAPI, UploadFile, File
from fastapi.responses import JSONResponse
import torch
import timm
from torchvision import transforms
from src.infer import build_model, build_transform, predict_video
from src.infer import build_model, build_transform, predict_video


app = FastAPI(title="Deepfake Detector (Xception + Haar)")

CKPT = os.environ.get("MODEL_CHECKPOINT", "checkpoints/xception_baseline/best.pt")
IMG_SIZE = int(os.environ.get("IMG_SIZE", "299"))

device = torch.device("cpu" if not torch.cuda.is_available() else "cuda")

@app.on_event("startup")
def _load_model():
    global model, tf
    model = build_model(img_size=IMG_SIZE, num_classes=1, pretrained=False).to(device)
    state = torch.load(CKPT, map_location=device)
    state = state.get("model", state)
    model.load_state_dict(state, strict=False)
    model.eval()
    tf = build_transform(img_size=IMG_SIZE)
    print(f"[READY] Loaded {CKPT} on {device}")

@app.get("/health")
def health():
    ok = os.path.exists(CKPT)
    return {"status": "ok" if ok else "missing-ckpt", "checkpoint": CKPT}

@app.post("/predict/video")
async def predict_video_endpoint(video: UploadFile = File(...)):
    # save to a secure temp file
    with tempfile.NamedTemporaryFile(delete=False, suffix=os.path.splitext(video.filename)[1]) as tmp:
        tmp_path = tmp.name
        shutil.copyfileobj(video.file, tmp)
    try:
        mean_score, scores = predict_video(
            video_path=tmp_path,
            model=model,
            tf=tf,
            device=device,
            every_n=1,       # sample every frame; you can change to 2 for speed
            min_face=60,     # adjust if faces are small
            margin=0.2,
            max_frames=None  # or cap like 300 for speed
        )
        return JSONResponse({
            "mean_prob_fake": round(float(mean_score), 4),
            "frames_used": len(scores)
        })
    finally:
        try:
            os.remove(tmp_path)
        except Exception:
            pass
