# src/evaluate.py
# Full Evaluation Script for Deepfake Detection
# Generates:
# - Performance Metrics Graph
# - Confusion Matrix
# - Real vs Fake Distribution
# - Class-wise Accuracy
# - ROC Curve
# - Precision-Recall Curve
# - Threshold Sensitivity Plot
# - Calibration Curve

import joblib
import numpy as np
import matplotlib
matplotlib.use("Agg")

import matplotlib.pyplot as plt
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    confusion_matrix, ConfusionMatrixDisplay,
    classification_report, roc_curve, auc,
    precision_recall_curve
)
from sklearn.calibration import calibration_curve

# -------------------------------------------------
# 1. Load embeddings
# -------------------------------------------------
data = np.load("../data/test_embeddings.npz")
X_test = data["embeddings"]
y_test = data["labels"]

print("Loaded embeddings:", X_test.shape)
print("Loaded labels:", y_test.shape)

# -------------------------------------------------
# 2. Load model
# -------------------------------------------------
clf = joblib.load("../checkpoints/emb_lr.pkl")
print("Logistic Regression model loaded")

# -------------------------------------------------
# 3. Predict
# -------------------------------------------------
y_pred = clf.predict(X_test)
y_probs = clf.predict_proba(X_test)[:, 1]

# -------------------------------------------------
# 4. Metrics
# -------------------------------------------------
accuracy  = accuracy_score(y_test, y_pred)
precision = precision_score(y_test, y_pred)
recall    = recall_score(y_test, y_pred)
f1        = f1_score(y_test, y_pred)

print("\n===== MODEL PERFORMANCE =====")
print(f"Accuracy  : {accuracy:.4f}")
print(f"Precision : {precision:.4f}")
print(f"Recall    : {recall:.4f}")
print(f"F1-score  : {f1:.4f}")

# -------------------------------------------------
# 5. Performance Bar Graph
# -------------------------------------------------
metrics = ["Accuracy", "Precision", "Recall", "F1-score"]
values = [accuracy, precision, recall, f1]

plt.figure(figsize=(6, 4))
plt.bar(metrics, values)
plt.ylim(0, 1)
plt.title("Deepfake Detection Performance")
plt.ylabel("Score")
plt.tight_layout()
plt.savefig("performance_metrics.png")
plt.close()

# -------------------------------------------------
# 6. Confusion Matrix
# -------------------------------------------------
cm = confusion_matrix(y_test, y_pred)
disp = ConfusionMatrixDisplay(confusion_matrix=cm)
disp.plot()
plt.title("Confusion Matrix")
plt.tight_layout()
plt.savefig("confusion_matrix.png")
plt.close()

# -------------------------------------------------
# 7. Real vs Fake Distribution
# -------------------------------------------------
real_count = (y_pred == 0).sum()
fake_count = (y_pred == 1).sum()

plt.figure(figsize=(5, 4))
plt.bar(["Real", "Fake"], [real_count, fake_count])
plt.title("Real vs Fake Prediction Distribution")
plt.ylabel("Number of Samples")
plt.tight_layout()
plt.savefig("real_vs_fake_comparison.png")
plt.close()

# -------------------------------------------------
# 8. Class-wise Accuracy
# -------------------------------------------------
report = classification_report(y_test, y_pred, output_dict=True)
real_acc = report["0"]["recall"]
fake_acc = report["1"]["recall"]

plt.figure(figsize=(5, 4))
plt.bar(["Real Accuracy", "Fake Accuracy"], [real_acc, fake_acc])
plt.ylim(0, 1)
plt.title("Class-wise Detection Accuracy")
plt.tight_layout()
plt.savefig("classwise_accuracy.png")
plt.close()

# -------------------------------------------------
# 9. ROC Curve
# -------------------------------------------------
fpr, tpr, _ = roc_curve(y_test, y_probs)
roc_auc = auc(fpr, tpr)

plt.figure(figsize=(5, 4))
plt.plot(fpr, tpr, label=f"AUC = {roc_auc:.2f}")
plt.plot([0, 1], [0, 1], linestyle="--")
plt.xlabel("False Positive Rate")
plt.ylabel("True Positive Rate")
plt.title("ROC Curve")
plt.legend()
plt.tight_layout()
plt.savefig("roc_curve.png")
plt.close()

# -------------------------------------------------
# 10. Precision–Recall Curve
# -------------------------------------------------
precisions, recalls, _ = precision_recall_curve(y_test, y_probs)

plt.figure(figsize=(5, 4))
plt.plot(recalls, precisions)
plt.xlabel("Recall")
plt.ylabel("Precision")
plt.title("Precision–Recall Curve")
plt.tight_layout()
plt.savefig("precision_recall_curve.png")
plt.close()

# -------------------------------------------------
# 11. Threshold Sensitivity Plot
# -------------------------------------------------
thresholds = np.linspace(0, 1, 50)
prec_list, rec_list = [], []

for t in thresholds:
    y_t = (y_probs >= t).astype(int)
    prec_list.append(precision_score(y_test, y_t))
    rec_list.append(recall_score(y_test, y_t))

plt.figure(figsize=(6, 4))
plt.plot(thresholds, prec_list, label="Precision")
plt.plot(thresholds, rec_list, label="Recall")
plt.xlabel("Threshold")
plt.ylabel("Score")
plt.title("Threshold Sensitivity Analysis")
plt.legend()
plt.tight_layout()
plt.savefig("threshold_sensitivity.png")
plt.close()

# -------------------------------------------------
# 12. Calibration Curve
# -------------------------------------------------
prob_true, prob_pred = calibration_curve(y_test, y_probs, n_bins=10)

plt.figure(figsize=(5, 4))
plt.plot(prob_pred, prob_true, marker="o", label="Model")
plt.plot([0, 1], [0, 1], linestyle="--", label="Perfectly Calibrated")
plt.xlabel("Mean Predicted Probability")
plt.ylabel("Fraction of Positives")
plt.title("Calibration Curve")
plt.legend()
plt.tight_layout()
plt.savefig("calibration_curve.png")
plt.close()

# -------------------------------------------------
# 13. Final Status
# -------------------------------------------------
print("\nGraphs saved successfully:")
print("- performance_metrics.png")
print("- confusion_matrix.png")
print("- real_vs_fake_comparison.png")
print("- classwise_accuracy.png")
print("- roc_curve.png")
print("- precision_recall_curve.png")
print("- threshold_sensitivity.png")
print("- calibration_curve.png")
print(f"ROC AUC Score: {roc_auc:.4f}")
