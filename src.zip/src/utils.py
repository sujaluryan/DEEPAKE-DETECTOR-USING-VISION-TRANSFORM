import os
import random
import time
import torch
import numpy as np
from sklearn import metrics

def set_seed(seed: int = 42):
    import torch.backends.cudnn as cudnn
    import random
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    cudnn.benchmark = True

def ensure_dir(path: str):
    os.makedirs(path, exist_ok=True)

class AverageMeter:
    def __init__(self):
        self.reset()
    def reset(self):
        self.sum = 0.0
        self.count = 0
    def update(self, val, n=1):
        self.sum += val * n
        self.count += n
    @property
    def avg(self):
        return self.sum / max(1, self.count)

def auc_roc(y_true, y_prob):
    try:
        return metrics.roc_auc_score(y_true, y_prob)
    except Exception:
        return float("nan")

def accuracy(y_true, y_pred, threshold=0.5):
    import numpy as np
    yp = (np.asarray(y_pred) >= threshold).astype(int)
    return (yp == np.asarray(y_true)).mean()

def timestamp():
    return time.strftime("%Y-%m-%d_%H-%M-%S")

def collate_with_vid(batch):
    # batch: list of (image_tensor, label, video_id)
    imgs, labels, vids = zip(*batch)
    import torch
    return torch.stack(imgs), torch.tensor(labels, dtype=torch.long), list(vids)
