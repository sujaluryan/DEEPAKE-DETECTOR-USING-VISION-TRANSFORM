import os
import torch
from torch.utils.data import Dataset
from torchvision import transforms
from PIL import Image

class VideoSequenceDataset(Dataset):

    def __init__(self, root_dir, sequence_length=16):

        self.root_dir = root_dir
        self.sequence_length = sequence_length

        self.samples = []

        self.transform = transforms.Compose([
            transforms.Resize((224,224)),
            transforms.ToTensor()
        ])

        for label, category in enumerate(["real","fake"]):

            category_path = os.path.join(root_dir, category)

            for video in os.listdir(category_path):

                video_path = os.path.join(category_path, video)

                frames = sorted(os.listdir(video_path))

                for i in range(len(frames) - sequence_length):

                    seq = frames[i:i+sequence_length]

                    seq_paths = [
                        os.path.join(video_path,f) for f in seq
                    ]

                    self.samples.append((seq_paths,label))


    def __len__(self):
        return len(self.samples)


    def __getitem__(self,idx):

        seq_paths,label = self.samples[idx]

        frames = []

        for path in seq_paths:

            img = Image.open(path)

            img = self.transform(img)

            frames.append(img)

        frames = torch.stack(frames)

        return frames,label