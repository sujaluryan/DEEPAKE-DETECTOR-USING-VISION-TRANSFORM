#!/usr/bin/env python3
# src/embed.py
"""
Embeddings extractor:
Reads a CSV with columns: path,label,video_id (path -> face-crop image)
Produces an .npz with arrays: embeddings, labels, paths, video_ids
Supports: --batch, --workers, --device (cpu|cuda), --backbone (resnet50|inceptionresnet)
"""

import argparse, os, sys, time
import numpy as np
import pandas as pd
from PIL import Image
from tqdm import tqdm

import torch
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms, models

# optional: try facenet if requested
USE_FACENET = False
try:
    from facenet_pytorch import InceptionResnetV1
    USE_FACENET = True
except Exception:
    USE_FACENET = False

class FaceCropsDataset(Dataset):
    def __init__(self, df, transform=None):
        self.df = df.reset_index(drop=True)
        self.transform = transform
    def __len__(self):
        return len(self.df)
    def __getitem__(self, idx):
        row = self.df.iloc[idx]
        p = row['path']
        lbl = int(row['label'])
        vid = row.get('video_id', "")
        try:
            img = Image.open(p).convert('RGB')
        except Exception as e:
            # return a black image if reading fails
            img = Image.new('RGB', (224,224), (0,0,0))
        if self.transform:
            img = self.transform(img)
        return img, lbl, p, vid

def build_backbone(backbone_name='resnet50', device='cpu'):
    if backbone_name == 'inceptionresnet' and USE_FACENET:
        # FaceNet gives 512-d embeddings
        model = InceptionResnetV1(pretrained='vggface2').eval().to(device)
        return model, 512, 'facenet'
    # default: ResNet50 without final fc, output 2048
    if backbone_name == 'resnet50':
        m = models.resnet50(weights=models.ResNet50_Weights.IMAGENET1K_V2)
        # remove classifier
        modules = list(m.children())[:-1]  # remove fc
        backbone = torch.nn.Sequential(*modules).to(device).eval()
        feat_dim = 2048
        return backbone, feat_dim, 'torch'
    # fallback: resnet34
    m = models.resnet34(weights=models.ResNet34_Weights.IMAGENET1K_V1)
    modules = list(m.children())[:-1]
    backbone = torch.nn.Sequential(*modules).to(device).eval()
    feat_dim = 512
    return backbone, feat_dim, 'torch'

def collate_fn(batch):
    imgs, labels, paths, vids = zip(*batch)
    imgs = torch.stack(imgs, dim=0)
    labels = torch.tensor(labels, dtype=torch.int64)
    return imgs, labels, list(paths), list(vids)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", required=True, help="metadata csv with columns path,label,video_id (video_id optional)")
    ap.add_argument("--out_npz", required=True, help="output .npz file")
    ap.add_argument("--batch", type=int, default=64)
    ap.add_argument("--workers", type=int, default=0, help="num_workers for DataLoader (0 recommended on Windows)")
    ap.add_argument("--device", type=str, default=None, help="cpu or cuda (auto if omitted)")
    ap.add_argument("--backbone", type=str, default="resnet50", choices=["resnet50","resnet34","inceptionresnet"], help="backbone to extract embeddings")
    ap.add_argument("--img_size", type=int, default=224)
    ap.add_argument("--no_tqdm", action="store_true")
    args = ap.parse_args()

    # device selection
    if args.device:
        device = torch.device(args.device)
    else:
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    print(f"[embed] device={device} backbone={args.backbone} batch={args.batch} workers={args.workers}")

    df = pd.read_csv(args.csv)
    # minimal column checks
    if 'path' not in df.columns or 'label' not in df.columns:
        raise SystemExit("CSV must contain 'path' and 'label' columns (video_id optional).")

    tf = transforms.Compose([
        transforms.Resize((args.img_size, args.img_size)),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485,0.456,0.406], std=[0.229,0.224,0.225]),
    ])

    ds = FaceCropsDataset(df, transform=tf)
    loader = DataLoader(ds, batch_size=args.batch, shuffle=False, num_workers=args.workers, collate_fn=collate_fn)

    backbone, feat_dim, impl = build_backbone(args.backbone, device=str(device))
    print(f"[embed] backbone impl={impl} feat_dim={feat_dim}")

    embeddings = np.zeros((len(ds), feat_dim), dtype=np.float32)
    labels = np.zeros((len(ds),), dtype=np.int64)
    paths = [None] * len(ds)
    vids = [None] * len(ds)

    idx = 0
    with torch.no_grad():
        it = loader
        if not args.no_tqdm:
            it = tqdm(loader, desc="Embedding", unit="batch")
        for batch in it:
            imgs, lbls, bpaths, bvids = batch
            imgs = imgs.to(device)
            # forward depends on impl
            if impl == 'facenet':
                out = backbone(imgs)  # facenet returns (N,512)
            else:
                out = backbone(imgs)  # N x feat_dim x 1 x 1
                out = out.view(out.size(0), -1)
            out_np = out.cpu().numpy()
            b = out_np.shape[0]
            embeddings[idx:idx+b] = out_np
            labels[idx:idx+b] = lbls.numpy()
            for i,p in enumerate(bpaths):
                paths[idx+i] = p
                vids[idx+i] = bvids[i] if bvids is not None else ""
            idx += b

    # trim in case
    embeddings = embeddings[:idx]
    labels = labels[:idx]
    paths = paths[:idx]
    vids = vids[:idx]

    os.makedirs(os.path.dirname(args.out_npz) or ".", exist_ok=True)
    np.savez_compressed(args.out_npz, embeddings=embeddings, labels=labels, paths=np.array(paths), video_ids=np.array(vids))
    print(f"[embed] Done. Saved {args.out_npz} shapes: embeddings={embeddings.shape}, labels={labels.shape}")

if __name__ == "__main__":
    main()
