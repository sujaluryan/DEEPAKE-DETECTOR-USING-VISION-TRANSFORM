import os
import io
import sys
import tempfile
from typing import Optional

import torch
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

# Make sure we can import from src/
THIS_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(THIS_DIR)
if PROJECT_ROOT not in sys.path:
    sys.path.append(PROJECT_ROOT)
if THIS_DIR not in sys.path:
    sys.path.append(THIS_DIR)

from src.infer import load_model, predict_video

APP_NAME = "Deepfake Detector API"
app = FastAPI(title=APP_NAME)

# CORS (adjust origins as needed)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Settings via env
MODEL_CHECKPOINT = os.getenv("MODEL_CHECKPOINT", "checkpoints/xception_baseline/best.pt")
MODEL_NAME = os.getenv("MODEL_NAME", "xception")
IMG_SIZE = int(os.getenv("IMG_SIZE", "299"))
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

MODEL = None
TF = None

@app.on_event("startup")
def _load_model_on_startup():
    global MODEL, TF
    if not os.path.exists(MODEL_CHECKPOINT):
        raise RuntimeError(f"Checkpoint not found at {MODEL_CHECKPOINT}. Train a model first or set MODEL_CHECKPOINT env.")
    MODEL, TF = load_model(MODEL_CHECKPOINT, model_name=MODEL_NAME, img_size=IMG_SIZE, device=DEVICE)

@app.get("/health")
def health():
    return {"status": "ok", "device": DEVICE, "model": MODEL_NAME, "img_size": IMG_SIZE}

class PredictVideoResponse(BaseModel):
    mean_prob_fake: float
    frames_used: int

@app.post("/predict/video", response_model=PredictVideoResponse)
async def predict_video_endpoint(
    video: UploadFile = File(..., description="Video file (mp4/avi/mov)"),
    fps: int = Form(5),
    min_face: int = Form(60),
    margin: float = Form(0.2),
):
    if MODEL is None or TF is None:
        raise HTTPException(status_code=500, detail="Model not loaded")

    # Save the uploaded file to a temp path
    suffix = os.path.splitext(video.filename or "upload.mp4")[-1]
    try:
        with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
            content = await video.read()
            tmp.write(content)
            temp_path = tmp.name
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Could not read uploaded file: {e}")

    try:
        mean_score, scores = predict_video(temp_path, MODEL, TF, device=DEVICE, fps=fps, min_face=min_face, margin=margin)
        return PredictVideoResponse(mean_prob_fake=float(mean_score), frames_used=len(scores))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Inference error: {e}")
    finally:
        try:
            os.remove(temp_path)
        except Exception:
            pass

# Run with: uvicorn src.server:app --host 0.0.0.0 --port 8000 --reload
